package org.testng.annotations;

/**
 * @author Hani Suleiman
 *         Date: Mar 6, 2007
 *         Time: 2:16:13 PM
 */
public interface IObjectFactoryAnnotation extends IAnnotation
{
}
