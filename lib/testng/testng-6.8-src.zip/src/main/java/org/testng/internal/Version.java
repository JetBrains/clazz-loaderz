package org.testng.internal;

public class Version {
  public static final String VERSION = "6.8beta 20120825_1010";

  public static void displayBanner() {
    System.out.println("...\n... TestNG " + VERSION + " by C�dric Beust (cedric@beust.com)\n...\n");
  }
}
